/*
 * To change this template, choose Tools | Templates and open the template in
 * the editor.
 */
package inspecttransform;

public class InspectTransform {
        
    public void m1(int a) {        
        a = a + 1;       
        
    }
    
    
}
