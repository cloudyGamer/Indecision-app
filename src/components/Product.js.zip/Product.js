/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import React from 'react'; 
import BriefProductSmall from './BriefProductSmall';
//import PHPFetch from './PHPFetch';
//import 'whatwg-fetch';
export default class Product extends React.Component {
  componentDidMount() {
  console.log('Product component did mount');
  }        
////////////////fetch
fetch = () => {
        var myList = document.querySelector('ul');
         /*var myRequest =  (`http://localhost:8888/3.0.2.0-OpenCart/upload/index.php?route=product/product&product_id=53`, {
            method: 'GET', // or 'PUT' 
           
            headers: {

            }s
        }); */         
        var other = `string`;
        var newString = JSON.stringify(other);
        console.log("get PHP executed");     
        window.fetch(`http://localhost:8888/3.0.2.0-OpenCart/upload/index.php?route=product/product&product_id=53`, {
            method: 'GET', // or 'PUT' 
           
            headers: {

            }
        }).then(function(response) { return response.json(); })
  .then(function(data) {
      console.log("result : "+ data.name);
    
      //// Product Name
      var productName  = document.getElementById("fetchTest");
      productName.innerHTML = '<strong>' + data.name + '</strong>';
     ////
     
     //// Product Image
     // var productImage  = document.getElementById("productImage");
      
      //const imageAddress ='http://localhost:8888/3.0.2.0-OpenCart/upload/image/'+data.image;
      const imageAddress ='assets/Pet_Set_1.png';

     
  });
 ////
           } 

//
fetch2 = () => {

        
        var other = `string`;
        var newString = JSON.stringify(other);
        console.log("get PHP executed");     
        window.fetch(`http://localhost:8888/3.0.2.0-OpenCart/upload/index.php?route=product/product&product_id=53`, {
            method: 'GET', // or 'PUT' 
           
            headers: {

            }
        }).then(function(response) { return response.json(); })
  .then(function(data) {
      
      var data = JSON.stringify(data);
      console.log("result : "+ data);
 /////////////////////////////////////////
 
       
  });
 {/*////*/}
 
 }
//////////////////////////////   
  

        render() {
        return(
       <div>
       <div className="masterDiv">
  <div>{/*{this.fetch2()}*/}</div>  
      {/*////// Top shelf /////*/}
            <div className="topShelf">
       {/*//// Top shelf side a ////*/}
                <div className="topShelf_sidea">
         {/*/// titleHold ///*/}
                      <div className="topShelf_titleHold">
                      
                 {/*// title //*/}
                       <div className="topShelf_titleHold_title">
                       <p id="fetchTest"></p>
                       </div>
                 {/*// *itle //*/}
                 
                 
                 {/*// subTitle //*/}
                        <div className="topShelf_titleHold_subtitle">
                        <p>subtitle</p>
                        </div>
                 {/*// *ubTitle //*/}
                 
                     </div>
        {/*/// *itleHold ///*/}
        
        {/*///star rating///*/}
                     <div className="topShelf_starRating">
                  {/*// stars //*/}
                     <div className = "topShelf_starRating_stars">* * * *</div>
                  {/*// *tars //*/}
                  {/*// 7 vegan //*/}
                     <div className = "topShelf_starRating_stars">7 Vegan</div>
                  {/*// * vegan //*/}
                     </div>
        {/*///*tar rating///*/}
                </div>
      {/*//// *op shelf side a ////*/}
      
      {/*//// Top shelf side b ////*/}
              <div className="topShelf_sideb">
        {/*///Image///*/}
                     <div className="topShelf_Image">
                     
                 {/*// photo //*/}
                 {/*<div>{console.log("check console"+data.image)}</div>*/}
                            {/*<img src={imageAddress2} className="topShelf_Image_photo"/>*/}
                        
                 {/*// *hoto //*/}
                 
                 {/*// vegan //*/}
                        
                             <img className="topShelf_Image_vegan" src="assets/V_de_Vegan.png" />
                         
                 {/*// *egan //*/}
                 
                     </div>
        {/*///*mage///*/}
              </div>
      {/*//// *op shelf side b ////*/}
                 
                 
            </div>
    {/*////// *op shelf /////*/}
                        
    {/*////// Mid shelf /////*/}
            <div className="midShelf">
      {/*////Price Bar container////*/} 
            <div className="midShelf_pricebarcontainer">
        {/*///Price Bar///*/}
                     <div className="midShelf_priceBar">
            
                     </div>
        {/*///*rice Bar///*/}
        {/*///quantity Bar///*/}
                     <div className="midShelf_quantity">
            
                     </div>
        {/*///*uantity Bar///*/}
            </div>
      {/*////*rice Bar container////*/}
      
      {/*////WishlistandBasketcontainer////*/}
            <div className="midShelf_wishListandBasketcontainer">
        {/*///Wishlistcontainer///*/}
            <div className="midShelf_wishListcontainer">       
            {/*//icon*/}
                           <div className="midShelf_wishList_icon">
                          
                           </div>
            {/*//*con*/}
            {/*//text*/}
                           <div className="midShelf_wishList_text">
                            
                           </div>
            {/*//*ext*/}
            </div>        
        {/*///*ishlistcontainer///*/}
                     
        {/*///Basketcontainer///*/}
                     <div className="midShelf_Basketcontainer">
            {/*//icon*/}
                           <div className="midShelf_Basketicon">
            
                           </div>
            {/*//*con*/}
            {/*//text*/}
                           <div className="midShelf_Baskettext">
            
                           </div>
            {/*//*ext*/}
                     </div>
        {/*///*asketcontainer///*/}
            </div>
     {/*////*ishlistandBasketcontainer////*/}
            </div>
    {/*////// *id shelf /////*/}
                        
    {/*////// Bottom shelf /////*/}
            <div className="bottomShelf">
                     
                     
        {/*///SocMedBut///*/}
                     <div className="bottomShelf_socMedButton">
            {/*//but1/*/}
                          <div className="bottomShelf_socMedButton_but1">
            
                          </div>
            {/*//*ut1/*/}
                     
            {/*//but2/*/}
                          <div className="bottomShelf_socMedButton_but1">
            
                          </div>
            {/*//*ut2/*/}
                     
            {/*//but3/*/}
                          <div className="bottomShelf_socMedButton_but1">
            
                          
                          </div>
            {/*//*ut3/*/}
                     </div>
        {/*///*ocMedBut///*/}
                     
                     
                     
        {/*///review///*/}
                     <div className="bottomShelf_review">
            {/*//review heading container/*/}
                     <div className="bottomShelf_review_heading">
            {/*//icon/*/}
                          <div className="bottomShelf_review_icon">
            
                          </div>
            {/*//*con/*/}
                     
            {/*//link/*/}
                          <div className="bottomShelf_review_link">
            
                          </div>
            {/*//*ink/*/}
                     </div>
            {/*//review heading container/*/}        
            {/*//text/*/}
                          <div className="bottomShelf_review_text">
The convenience of a face wipe meets the luxury of 9 To 5 cream cleanser, with none of the waste. This reusable, biodegradable cleanser and makeup remover feels gentle on the skin, thanks to the carrageenan and finely ground cannellini bean base with clarifying fresh dove orchid infusion and ylang ylang to balance. Simply splash your face with water, wet one side the pad, and glide over your face to activate a light cleansing cream that can be gently worked into the skin and rinsed away. Remove light eye makeup too by sweeping the wet cleansing wipe over your eyelids to gently rub away mascara and rinsing clean. Cleansing complete, you can then finish your routine as usual.
                          </div>
            {/*//*ext/*/}
                     </div>
        {/*///*eview ///*/}
                     
        {/*/// Ing ///*/}
                     <div className="bottomShelf_ing">
            {/*//titleHolder///*/}
                     <div className="titleHolder">
                     {/*//title//*/}
                          <div className="titleHolder_title">
                          Ingredients
                          </div>
                     {/*//*itle//*/}
                     {/*//Arrow//*/}
                          <div className="titleHolder_arrow">
                          arrow
                          </div>
                     {/*//*rrow//*/}
                     </div>
            {/*//*itleHolder///*/}
            {/*//*ottomShelf_Ing_holder//*/}
            <div className="bottomShelf_Ing_holder">
              {/*//bottomShelf_Ing_left//*/}
                     <div className="bottomShelf_Ing_left">
                     {/*//feat1///*/}
                          <div className="bottomShelf_Ing_feat">
                          {/*//container///*/}
                          <div className="posAbs">
                          {/*/featImg//*/}
                                <div className="bottomShelf_Ing_feat_featImg centeredText">
                           image 1
                           {/*/featTitle//*/}
                                <div className="bottomShelf_Ing_feat_featTitle">
                                clearing for skin
                                </div>
                                {/*/*eatTitle//*/}
                     
                                {/*/featSubTitle//*/}
                                <div className="bottomShelf_Ing_feat_featSubTitle">
                                ylang ylang
                                </div>
                               {/*/*eatSubTitle//*/}
                                </div>
                          {/*/*eatImg//*/}
           
                          </div>
                    {/*//*ontainer///*/} 
                          </div>
                    {/*//*eat1///*/}
                    
                    {/*//feat2///*/}
                          <div className="bottomShelf_Ing_feat">
                          {/*//container///*/}
                          <div className="posAbs">
                          {/*/featImg//*/}
                                <div className="bottomShelf_Ing_feat_featImg centeredText">
                                 image2
                                 {/*/featTitle//*/}
                                <div className="bottomShelf_Ing_feat_featTitle">
                                clearing for skin
                                </div>
                                {/*/*eatTitle//*/}
                     
                                {/*/featSubTitle//*/}
                                <div className="bottomShelf_Ing_feat_featSubTitle">
                                ylang ylang
                                </div>
                               {/*/*eatSubTitle//*/}
                                </div>
                           
                      
                    </div>
                    {/*//*ontainer///*/}
                          </div>
                    {/*//*eat2///*/}
                          
                   </div>
              {/*//*ottomShelf_Ing_left//*/}
              {/*//bottomShelf_Ing_right//*/}
                   <div className="bottomShelf_Ing_right">
                   {/*//feat3///*/}
                   
                          <div className="bottomShelf_Ing_feat">
                     {/*//container///*/}
                          <div className="posAbs">
                          {/*/featImg//*/}
                                <div className="bottomShelf_Ing_feat_featImg centeredText">
                                image 3
                                {/*/featTitle//*/}
                                <div className="bottomShelf_Ing_feat_featTitle">
                                clearing for skin
                                </div>
                                {/*/*eatTitle//*/}
                     
                                {/*/featSubTitle//*/}
                                <div className="bottomShelf_Ing_feat_featSubTitle">
                                ylang ylang
                                </div>
                               {/*/*eatSubTitle//*/} 
                                </div>
                           {/*/*eatImg//*/}
                          </div>
                    {/*//*ontainer///*/}     
                          </div>
                  {/*//*eat3///*/}
                 
            
                     </div>
             {/*//*ottomShelf_Ing_right//*/}
                     </div>
           {/*//*ottomShelf_Ing_holder//*/}
                     </div>
                     
        {/*/// listIng   ///*/}
                     <div className="listIng">
            {/*//title//*/}
                    <div className="listIng_title">
                    List of Ingredients
                    </div>
            {/*//*itle//*/}
            {/*//list//*/}
                    <div className="bottomShelf_listIng_list ">
                    <ul className="bottomShelf_listIng_noBullets">
                    <li>Ing1</li>
                    <li>Ing2</li>
                    <li>Ing3</li>
                    </ul>
                    </div>
            {/*//*ist//*/}
            {/*//legend//*/}
                    <div className="bottomShelf_listIng_legend">
                    </div>
            {/*//*egend//*/}
                     </div>
        {/*/// *isntIng   ///*/}
            
        {/*/// Rel ///*/}
                     <div className="bottomShelf_rel">
            {/*//titleHolder///*/}
                     <div className="titleHolder">
                     {/*//title//*/}
                          <div className="titleHolder_title">
                          Related Article
                          </div>
                     {/*//*itle//*/}
                     {/*//Arrow//*/}
                          <div className="titleHolder_arrow">
                          arrow
                          </div>
                     {/*//*rrow//*/}
                     </div>
            {/*//*itleHolder///*/}
            {/*//bigImage//*/}
                     <div className="bottomShelf_rel_bigImage">
                     {/*/title/*/}
                     <div className="bottomShelf_rel_bigImage_title">
                     title text about our great offer
                     </div>
                     {/*/*itle/*/}
                     
                     {/*/button/*/}
                     <div className="bottomShelf_rel_bigImage_button border"> 
                             {/*text*/}
                             <div className="bottomShelf_rel_bigImage_button_text">
                              Button Text
                             </div>
                             {/**ext*/}
                     </div>
                     {/*/*utton/*/}
                     
                             
                     </div>
            {/*//*igimage//*/}
                     </div>
        {/*/// *el    ///*/}
                     
        {/*/// Reviews ///*/}
                     <div className="bottomShelf_reviews">
            {/*//titleHolder//*/}
                      <div className="titleHolder"> 
                     {/*/title//*/}
                     <div className="titleHolder_title">
                     Reviews
                     </div>
                     {/*/*itle//*/}
                     
                     {/*/arrow//*/}
                     <div className="titleHolder_arrow">
                      Arrow
                     </div>
                     {/*/*rrow//*/}
                      </div>
            {/*//*itleHolder//*/}
                     
                      
            {/*//avgRating/*/}
                          <div className="bottomShelf_reviews_avgRating greyBorder">
                     {/*/stars/*/}
                                <div className="bottomShelf_reviews_avgRating_stars">
                                 *****
                                </div>
                     {/*/*tars/*/}
                     {/*/number/*/}
                                <div className="bottomShelf_reviews_avgRating_number">
                                 3.3
                                </div>
                     {/*/*umber/*/}
                     {/*/subtitle/*/}
                                <div className="bottomShelf_reviews_avgRating_subtitle">
                                Average Rating
                                </div>
                     {/*/*ubtitle/*/}
                     
                          </div>
             {/*//*vgRating//*/}
             {/*//singReview//*/}
                           <div className="bottomShelf_reviews_singReview greyBorder">
                     {/*/title/*/}
                           <div className="bottomShelf_reviews_singReview_title">
                           Most Helpful
                           </div>
                     {/*/*itle/*/}
                     {/*/subTitle/*/}
                           <div className="bottomShelf_reviews_singReview_subTitle">
                           3/3 people sound this helpful
                           </div>
                     {/*/*ubTitle/*/}
                     {/*/picture/*/}
                           <div className="bottomShelf_reviews_singReview_picture">
                           picture
                           </div>
                     {/*/*icture/*/}
                     {/*/userName/*/}
                           <div className="bottomShelf_reviews_singReview_userName">
                           Ashy
                           </div>
                     {/*/*serName/*/}
                     {/*/stars/*/}
                           <div className="bottomShelf_reviews_singReview_stars">
                            ****
                           </div>
                     {/*/*tars/*/}
                     
                     
                     {/*/text/*/}
                           <div className="bottomShelf_reviews_singReview_text">
                           I bought 3 of these yesterday after talking to the sales assistant who advised these would last around a week and are revolutional.
However after 24hrs and 2 uses the first one has just turned to mush even though I placed it on a dry flannel and then a clean dry drainer. Definitely wouldn’t last 3-5 uses as the website suggests.
                           </div>
                     {/*/*ext/*/}
                     </div>
             {/*//*ingReview//*/}
             
                     </div>
        {/*/// *eviews ///*/}
          
                     
        {/*/// Relcontent ///*/}
                     <div className="bottomShelf_relContent">
                     {/*<div className="test"></div>
                     <div className="test"></div>
                     <div className="test"></div>
                     <div className="test"></div>
                     <div className="test"></div>
                     <div className="test"></div>
                     <div className="test"></div>*/}
                    {/* <BriefProductSmall 
                      imageAddress={imageAddress2}
                      productName = {productName2}
                      productDesc = {productDesc2}
                     />
                     
                     <BriefProductSmall 
                      imageAddress={imageAddress2}
                      productName = {productName2}
                      productDesc = {productDesc2}
                     />
                     
                     <BriefProductSmall 
                      imageAddress={imageAddress2}
                      productName = {productName2}
                      productDesc = {productDesc2}
                     />
                     
                     <BriefProductSmall 
                      imageAddress={imageAddress2}
                      productName = {productName2}
                      productDesc = {productDesc2}
                     />
                     
                     <BriefProductSmall 
                      imageAddress={imageAddress2}
                      productName = {productName2}
                      productDesc = {productDesc2}
                     />*/}
                    
             {/*//Rel1//*/}
                     <div className="bottomShelf_relContent_rel">
                     {/*/picHolder/*/}
                     <div className="bottomShelf_relContent_rel_picHolder">
                            {/*pic*/}
                            <div className="bottomShelf_relContent_rel_picHolder_pic">
                            </div>
                            {/**ic*/}
                            {/*symbol*/}
                            <div className="bottomShelf_relContent_rel_picHolder_symbol">
                            </div>
                            {/**ymbol*/}
                     </div>
                     {/*/*icHolder/*/}
                            {/*/title/*/}
                            <div className="bottomShelf_relContent_rel_title">
                            </div>
                            {/*/*itle/*/}
                            {/*/subtitle/*/}
                            <div className="bottomShelf_relContent_rel_subtitle">
                            </div>
                            {/*/*ubtitle/*/}
                            
                            {/*/subtitle/*/}
                            <div className="bottomShelf_relContent_rel_subtitle">
                            </div>
                            {/*/*ubtitle/*/}
                            {/*/price/*/}
                            <div className="bottomShelf_relContent_rel_price">
                            </div>
                            {/*/*rice/*/}
                     </div>
             {/*//*el1//*/}
                     </div>
                     
        {/*/// *elcontent ///*/}
            
            </div>   
    {/*////// *ottom shelf /////*/}
    {/*////// footer /////*/}
            <div>
            </div>
    {/*////// *ooter /////*/}
    </div>
 {/*//////////masterDiv//////////*/}               
      </div>); 
               
               }

}