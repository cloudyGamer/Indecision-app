import React from 'react'; 
//import from './'
import Header from './Header';
import Options from './Options';
import AddOption from './AddOption';
import Action from './Action';
import OptionModal from './OptionModal';
import PHPFetch from './PHPFetch';
import Banner from './Banner'
import ToolBar from './ToolBar'
import BigImage from './BigImage'
import BriefProduct from './BriefProduct'
import BriefReview from './BriefReview'
import BlogFeature from './BlogFeature'
import BlogFeatureLeft from './BlogFeatureLeft'
import {blogImageAddresses} from './Props'
import ProductPage from './ProductPage'
import Product from './Product'
import Basket from  './Basket'
import EnterEmail1 from './EnterEmail1'
//import Template from './Template'

export default class IndecisionApp extends React.Component {
/////////////////////////////////////////////////////////// main component
        //new state
        state =  {
            resources: [{"name": "fig"}, {"name": "Donna"}],
            selectionOption : undefined,
            options: [],
            test: undefined,
            currentProduct: undefined
            
            
        } 
        
     closeModal = () => {
     this.setState(()=>({
             selectedOption : undefined
         }));   
     }

     handleDeleteOptions = () => {
         this.setState(() => ({ options: [] }));
       }
  
     counterEs6 = () => {

     this.setState((prevState)=>{
                 return {counter: prevState.counter+1};
             });
     console.log("COUNTERES6 RAN WITH VALUE_____"+this.state.counter);           
     }  
///////////////////////////////////////////////////////// route     
     route = (data)=> {
 //////////////////////////
console.log("route executed with parameter"+data);
//const testStr = "product/product&product_id=53";
  window.fetch(`http://localhost:8888/3.0.2.0-OpenCart/upload/index.php?route=`+data);
  //////////////////////////     
 }       
 ///////////////////////////////////////////////////////// *oute   
 
///////////////////////////////////////////////////////// fetch 
 fetch = (data) => {
//////////////////////////
console.log("fetch executed with parameter"+data);
const testStr = "product/product&product_id=53";
  window.fetch(`http://localhost:8888/3.0.2.0-OpenCart/upload/index.php?route=`+data, {
            method: 'GET', // or 'PUT' 
           
            headers: {

            }
        }).then(response => response.json())
    .then (json => 
          
          this.setState({
          resources: json
          
     }))
 //////////////////////////        
 }
 ///////////////////////////////////////////////////////// *etch 
 /////////////////////////////////////////////////// routeMultiple
 routeMultiple = (route,stateParam) => {
console.log("route multiple executed");
//////////////////////////
//console.log("state"+stateParam);
const  newArray = [];
 ///////////
for(var prop in stateParam) {           
newArray.push(prop); 
///////////
}
console.log("routeMultiple newArray(push)  /"+newArray[1]);
//////// working code - still working
 const testArray2 = Object.keys(stateParam).map(i => stateParam[i]) ;
console.log("routeMultiple testArray2(obj.kesy)   /"+testArray2);
///////////
for (var index = 0; index < newArray.length; index++) {
 newArray[index] = "&"+ newArray[index] + "="+testArray2[index];
   //console.log("newArray"+ newArray[index]); 
}    
const urlParameters = newArray.join('');
console.log("final string  /"+route+urlParameters);
const testStr2 = "product/product&product_id=53";
////// fetch
  window.fetch("`http://localhost:8888/3.0.2.0-OpenCart/upload/index.php?route="+route+urlParameters+"`");

 ///// *fetch   
console.log("state is equal to:"+this.state.value);
     }
 //////////////////////////  
 ///////////////////////////////////////////////////*outeMultiple
 
 /////////////////////////////////////////////////// routemultiplePost
 routeMultiplePost = (route,stateParam) => {
console.log("route multiple executed");
//////////////////////////
//console.log("state"+stateParam);
const  newArray = [];
 ///////////
for(var prop in stateParam) {           
newArray.push(prop); 
///////////
}
console.log("routemultiplePost newArray(push)  /"+newArray[1]);
//////// working code - still working
 const testArray2 = Object.keys(stateParam).map(i => stateParam[i]) ;
console.log("routemultiplePost testArray2(obj.kesy)   /"+testArray2);
///////////
for (var index = 0; index < newArray.length; index++) {
 newArray[index] = "&"+ newArray[index] + "="+testArray2[index];
   //console.log("newArray"+ newArray[index]); 
}    
const urlParameters = newArray.join('');
console.log("final string  /"+route+urlParameters);
const testStr2 = "product/product&product_id=53";
////// fetch
  window.fetch("`http://localhost:8888/3.0.2.0-OpenCart/upload/index.php?route="+route+urlParameters+"`", {
            method: 'POST', // or 'PUT' 
           
            headers: {

            }
        }).then(response => response.json())
    .then (json => 
          console.log("resources json"+json),
         {/*     this.setState({
          resources: json
          
     })*/})

 ///// *fetch   
console.log("state is equal to:"+this.state.value);
     }
 //////////////////////////  
 ///////////////////////////////////////////////////*outemultiplePost
 
 
 ///////////////////////////////////////////////////////// toCheckout
 toCheckout = () => {
console.log("toCheckout function executed");

//////////////////////////

 }
///////////////////////////////////////////////////////// *ocheckout
 
 ///////////////////////////////////////////////////////// test
 test = () => {
console.log("test function executed");
const test = "testStr";
this.setState(()=>({
        test : "testStr"
    }));
//////////////////////////
//console.log("test state now changed to:___"+this.state.test);
 }
///////////////////////////////////////////////////////// *est 
 
 
 handleDeleteOption = (optionToRemove) => {
    this.setState((prevState) => ({
      options: prevState.options.filter((option) => optionToRemove !== option)
    }));
  };
  
  handlePick = () => {
      console.log('handle pick fired');
    const randomNum = Math.floor(Math.random() * this.state.options.length);
    const option = this.state.options[randomNum];
    this.setState(()=>({
        selectedOption : option
    }));
  };
  
  handleAddOption = (option) => {
    if (!option) {
      return 'Enter valid value to add item';
    } else if (this.state.options.indexOf(option) > -1) {
      return 'This option already exists';
    }

    this.setState((prevState) => ({
      options: prevState.options.concat(option)
    }));
  };
  
  componentDidMount() {
       
 //{this.test()} 
    try {
      const json = localStorage.getItem('options');
      const options = JSON.parse(json);

      if (options) {
        this.setState(() => ({ options }));
      }
    } catch (e) {
      // Do nothing at all
    }
  }
  
  componentDidUpdate(prevProps, prevState) {
      console.log("update - "+this.state.selectedOption);
    if (prevState.options.length !== this.state.options.length) {
      const json = JSON.stringify(this.state.options);
      localStorage.setItem('options', json);
    }
  }
  componentWillUnmount() {
    console.log('componentWillUnmount');
  }
  
  render() {
/////////////////////////////////////////// render

{console.log("test state now changed to:___"+this.state.test);}
<editor-fold>
const exampleText = 'this is example text';
    const subtitle = 'testing all files are working';
    const imageAddress1 = 'assets/all-the-jingle-ladies-sack.png';
    const imageAddress2 = 'assets/christmas_carol_1.png';
    const productName1 = 'Bath Blaster';
    const productDesc1 = 'Enjoy the bubbles';
    const productName2 = 'Christmas Carol';
    const productDesc2 = 'Lovely Gift set';
    //const blogImage1 = "url('/assets/blog_image_1.jpg')";
     //const blogImage2 = "url('/assets/stockingFiller 2.jpg')";
     //const blogImage3 = "url('/assets/Pet_Set_1.png')";
     
    const bigImageAddress1 = "url('/assets/stockingFiller.jpg')";
    const bigImageAddress2 = "url('/assets/bigImage_2.png')";
    const container_bigImageMarginAndPadding = "container_bigImageMarginAndPadding";
    const container_bigImageMargin = "container_bigImageMargin";
    const color = "red";
    
   ///////////////////// product page const
   /*const name = this.state.resources.name;
   const description = this.state.resources.description 
   const quantity = this.state.resources.quantity;
   const image = this.state.resources.image;
   const price = this.state.resources.price;
   const imageAd = "http://localhost:8888/3.0.2.0-OpenCart/upload/image/" + image;*/
   ///////////////////// *product page const
</editor-fold>
////////////////////////////*eturn    
    return (
               <div>
              {/*   <Product 
          fetch={this.fetch}
          route={this.route}
          name = {this.state.resources.name}
         description = {this.state.resources.description}
          quantity = {this.state.resources.quantity}
        image  = {this.state.resources.image}
         price = {this.state.resources.price}
         test = {this.test}
         testState = {this.state.test}
               />*/}
       
       
               {/* <Basket
       fetch={this.fetch}
       route={this.route}
       name = {this.state.resources.name}
       description = {this.state.resources.description}
       quantity = {this.state.resources.quantity}
       image  = {this.state.resources.image}
       price = {this.state.resources.price}
       /> */}
       
           <EnterEmail1 
       routeMultiple = {this.routeMultiple}
       route = {this.route}
       routeMultiplePost = {this.routeMultiplePost}
       fetch = {this.fetch}
       resources = {this.state.resources}
               />       
       {/*<Banner />
       <ToolBar />*/}
               
       {/*<BigImage 
       imageAddress = {bigImageAddress1}
      container_bigImage = {container_bigImageMargin}
       color = {color}
            /> 
       
       <div className="sectionContainer">
       <div className="briefContainerTest">
       <BriefProduct 
       imageAddress={imageAddress1}
       productName = {productName1}
       productDesc = {productDesc1}
            />
       <BriefReview />
       </div>
       
       <div className="briefContainerTest">
       <BriefProduct 
       imageAddress={imageAddress2}
       productName = {productName2}
       productDesc = {productDesc2}
       
            />*/}
     {/*<BlogFeature 
       blogImage = {blogImageAddresses.blogImage2}
       propFunction = {this.iterateProps}
            />*/}
            
     {/*  <BlogFeature 
     exampleText = {exampleText}
     blogImage = {blogImageAddresses.blogImage1}
     counter = {this.state.counter}
     counterEs6 = {this.counterEs6}
            />     
          
          
     <BlogFeature 
     exampleText = {exampleText}
     blogImage = {blogImageAddresses.blogImage1}
     counter = {this.state.counter}
     counterEs6 = {this.counterEs6}
            />          
            
       </div>
       </div>*/}  
               
     {/*
       <BigImage 
        imageAddress = {bigImageAddress2}
        container_bigImage = {container_bigImageMarginAndPadding}
            /> */}
       
            <div className="briefContainerTest">
            {/*<BlogFeatureLeft 
       blogImage = {blogImage3}
            />*/}
            
           {/* <BlogFeature 
       blogImage = {blogImage1}
            />*/}
            </div>
            
            {/*<BigImage 
         imageAddress = {bigImageAddress2}
            /> */}
               
     {/*<div className="briefContainer_test">Brief Product</div>
     <div className="briefContainer_test">Blog Post 1</div>
     <div className="briefContainer_test">Blog Post 2</div>
     <div className="briefContainer_test">image with text</div>
     <div className="briefContainer_test">Brief Product</div>*/}
               
   {/*
        <Header subtitle={subtitle}
     
        />
         <div className="container">
        <Action
          hasOptions={this.state.options.length > 0}
          handlePick={this.handlePick}
        />
        
        <div className="widget">
        <Options
          options={this.state.options}
          handleDeleteOptions={this.handleDeleteOptions}
          handleDeleteOption={this.handleDeleteOption}
        />
        <AddOption
          handleAddOption={this.handleAddOption}
        />
        </div>
        
        </div>
        <OptionModal
        selectedOption={this.state.selectedOption}
                closeModal = {this.closeModal}
                    />*/}  
     
               </div>
////////////////////////////return    
               )
/////////////////////////////////////////// *ender
  }
/////////////////////////////////////////////////////////// *ain component   
     }
     
IndecisionApp.defaultProps = {
  options: []
};